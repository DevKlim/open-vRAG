// content.js - Injects buttons into X.com and Reddit

console.log("[vChat] Extension loaded.");

// --- TWITTER / X.COM LOGIC ---

function injectTwitterButtons() {
    // Select tweets that don't have our buttons yet
    const tweets = document.querySelectorAll('article[data-testid="tweet"]:not(.vchat-processed)');
    
    tweets.forEach(tweet => {
        tweet.classList.add('vchat-processed');
        
        // Find the action bar (Reply, Retweet, Like, Share)
        const actionBar = tweet.querySelector('[role="group"]');
        
        if (actionBar) {
            // Get the Tweet Link
            const timeElement = tweet.querySelector('a[href*="/status/"]');
            const tweetLink = timeElement ? timeElement.href : window.location.href;
            
            // Get basic caption text
            const textElement = tweet.querySelector('[data-testid="tweetText"]');
            const caption = textElement ? textElement.innerText : "";

            createButtonUI(actionBar, tweetLink, caption);
        }
    });
}

// --- DOM MANIPULATION HELPERS ---

function createButtonUI(container, link, caption) {
    const wrapper = document.createElement('div');
    wrapper.className = 'vchat-btn-group';
    
    // Batch Ingest Button
    const btnIngest = document.createElement('button');
    btnIngest.className = 'vchat-btn';
    btnIngest.innerText = '⚡ Batch';
    btnIngest.onclick = (e) => {
        e.stopPropagation();
        handleIngest(link, btnIngest);
    };
    
    // Manual Label Button
    const btnManual = document.createElement('button');
    btnManual.className = 'vchat-btn manual';
    btnManual.innerText = '📝 Label';
    btnManual.onclick = (e) => {
        e.stopPropagation();
        openManualLabel(link, caption);
    };

    wrapper.appendChild(btnIngest);
    wrapper.appendChild(btnManual);
    
    // Insert after the existing action bar or append to it
    container.parentElement.appendChild(wrapper);
}

// --- ACTIONS ---

function handleIngest(link, btnElement) {
    btnElement.innerText = '⏳...';
    
    chrome.runtime.sendMessage({type: 'INGEST_LINK', link: link}, (response) => {
        if (response && response.success) {
            btnElement.innerText = '✔ Queued';
            btnElement.style.backgroundColor = '#10b981';
        } else {
            btnElement.innerText = '❌ Error';
            btnElement.style.backgroundColor = '#ef4444';
            console.error(response ? response.error : 'Unknown error');
        }
        setTimeout(() => {
             if(btnElement.innerText === '✔ Queued') btnElement.innerText = '⚡ Batch';
        }, 3000);
    });
}

function openManualLabel(link, caption) {
    // Open the manual label form in a new window/tab
    const encodedLink = encodeURIComponent(link);
    const encodedCaption = encodeURIComponent(caption);
    const url = chrome.runtime.getURL(`src/manual_label.html?link=${encodedLink}&caption=${encodedCaption}`);
    
    window.open(url, 'vChatLabel', 'width=500,height=800,scrollbars=yes');
}

// --- OBSERVER ---

// Use MutationObserver to handle infinite scroll on SPA like X.com
const observer = new MutationObserver((mutations) => {
    injectTwitterButtons();
});

observer.observe(document.body, { childList: true, subtree: true });

// Initial run
injectTwitterButtons();