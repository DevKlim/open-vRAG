document.getElementById('btn-settings').addEventListener('click', () => {
    alert("Configuration settings would go here (e.g. changing backend URL). Currently defaults to localhost:8005.");
});